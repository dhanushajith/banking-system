# Online Banking System (Spring Boot)

REST API for a simple bank: JWT login, accounts, deposit / withdraw / transfer,
paginated transaction history, monthly reports and large-transaction alerts.

**Stack:** Java 17, Spring Boot 3.2, Spring Security + JWT, Spring Data JPA (Hibernate),
H2 (default) or MySQL, Maven, JUnit 5 + Mockito, Swagger/OpenAPI, Lombok.

## Run

```bash
mvn spring-boot:run          # starts on http://localhost:8080 with in-memory H2
mvn test                     # runs unit tests
```

- Swagger UI: http://localhost:8080/swagger-ui.html
- H2 console: http://localhost:8080/h2-console (JDBC URL `jdbc:h2:mem:bankdb`, user `sa`, empty password)
- Seeded admin: `admin` / `admin123`

To use MySQL, edit `application.properties` (instructions inside).

## Try it

```bash
# 1. register and log in
curl -X POST localhost:8080/api/auth/register -H "Content-Type: application/json" \
  -d '{"username":"alice","password":"secret123","email":"alice@mail.com"}'
curl -X POST localhost:8080/api/auth/login -H "Content-Type: application/json" \
  -d '{"username":"alice","password":"secret123"}'
# copy the token from the response:  TOKEN=eyJ...

# 2. create an account, deposit, check history
curl -X POST localhost:8080/api/accounts -H "Authorization: Bearer $TOKEN"
curl -X POST localhost:8080/api/accounts/<ACCOUNT_NUMBER>/deposit -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" -d '{"amount":500}'
curl "localhost:8080/api/accounts/<ACCOUNT_NUMBER>/transactions?type=DEPOSIT&page=0&size=5" \
  -H "Authorization: Bearer $TOKEN"
```

## Endpoints

| Method | Path | Description |
|---|---|---|
| POST | /api/auth/register | Register user |
| POST | /api/auth/login | Get JWT |
| POST | /api/accounts | Create account |
| GET | /api/accounts | List my accounts |
| POST | /api/accounts/{no}/deposit | Deposit |
| POST | /api/accounts/{no}/withdraw | Withdraw |
| POST | /api/accounts/transfer | Transfer between accounts |
| GET | /api/accounts/{no}/transactions | History (pagination + `type` filter) |
| GET | /api/accounts/{no}/report?year=&month= | Monthly in/out/net |
| GET | /api/admin/accounts | All accounts (ADMIN only) |

## Design points to talk about in an interview

- **Layered architecture:** Controller -> Service -> Repository, DTOs (records) separate from entities.
- **Data consistency:** `@Transactional` on transfers, so both balance updates and both ledger entries commit or roll back together.
- **Concurrency:** `@Version` on `Account` (optimistic locking); a conflicting update returns HTTP 409.
- **Security:** BCrypt password hashing, stateless JWT filter, role-based access (`/api/admin/**`), ownership checks so users can only touch their own accounts.
- **Money handling:** `BigDecimal` with precision/scale, never `double`.
- **Performance:** composite index on `transactions(account_id, created_at)`; pagination on history.
- **Validation and errors:** Bean Validation on requests, `@RestControllerAdvice` for consistent JSON errors.
- **Testing:** Mockito unit tests for deposit, withdraw, transfer, and access control.

## Ideas to extend it
Real email via `spring-boot-starter-mail`, Docker + docker-compose with MySQL, refresh tokens,
Flyway migrations, Testcontainers integration tests, pessimistic locking for hot accounts.
