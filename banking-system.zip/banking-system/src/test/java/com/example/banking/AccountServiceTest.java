package com.example.banking;

import com.example.banking.dto.Dtos.AccountResponse;
import com.example.banking.dto.Dtos.TransferRequest;
import com.example.banking.entity.Account;
import com.example.banking.entity.Transaction;
import com.example.banking.entity.User;
import com.example.banking.exception.InsufficientFundsException;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.TransactionRepository;
import com.example.banking.repository.UserRepository;
import com.example.banking.service.AccountService;
import com.example.banking.service.NotificationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AccountServiceTest {
    @Mock AccountRepository accounts;
    @Mock UserRepository users;
    @Mock TransactionRepository transactions;
    @Mock NotificationService notifications;
    @InjectMocks AccountService service;

    private Account account(String number, String balance, String ownerName) {
        User u = new User();
        u.setUsername(ownerName);
        Account a = new Account();
        a.setAccountNumber(number);
        a.setBalance(new BigDecimal(balance));
        a.setOwner(u);
        return a;
    }

    @Test
    void depositIncreasesBalanceAndRecordsTransaction() {
        Account a = account("AC1", "100", "alice");
        when(accounts.findByAccountNumber("AC1")).thenReturn(Optional.of(a));

        AccountResponse r = service.deposit("AC1", new BigDecimal("50"), "alice");

        assertEquals(0, new BigDecimal("150").compareTo(r.balance()));
        verify(transactions).save(any(Transaction.class));
    }

    @Test
    void withdrawFailsWhenBalanceTooLow() {
        Account a = account("AC1", "20", "alice");
        when(accounts.findByAccountNumber("AC1")).thenReturn(Optional.of(a));

        assertThrows(InsufficientFundsException.class,
                () -> service.withdraw("AC1", new BigDecimal("50"), "alice"));

        assertEquals(0, new BigDecimal("20").compareTo(a.getBalance()));
        verify(transactions, never()).save(any());
    }

    @Test
    void transferMovesMoneyBetweenAccounts() {
        Account from = account("AC1", "500", "alice");
        Account to = account("AC2", "100", "bob");
        when(accounts.findByAccountNumber("AC1")).thenReturn(Optional.of(from));
        when(accounts.findByAccountNumber("AC2")).thenReturn(Optional.of(to));

        service.transfer(new TransferRequest("AC1", "AC2", new BigDecimal("200")), "alice");

        assertEquals(0, new BigDecimal("300").compareTo(from.getBalance()));
        assertEquals(0, new BigDecimal("300").compareTo(to.getBalance()));
        verify(transactions, times(2)).save(any(Transaction.class));
    }

    @Test
    void cannotTransferToSameAccount() {
        assertThrows(IllegalArgumentException.class,
                () -> service.transfer(new TransferRequest("AC1", "AC1", BigDecimal.TEN), "alice"));
    }

    @Test
    void cannotUseSomeoneElsesAccount() {
        Account a = account("AC1", "100", "alice");
        when(accounts.findByAccountNumber("AC1")).thenReturn(Optional.of(a));

        assertThrows(AccessDeniedException.class,
                () -> service.deposit("AC1", BigDecimal.TEN, "mallory"));
    }
}
