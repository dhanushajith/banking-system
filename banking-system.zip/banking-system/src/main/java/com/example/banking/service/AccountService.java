package com.example.banking.service;

import com.example.banking.dto.Dtos.*;
import com.example.banking.entity.*;
import com.example.banking.exception.InsufficientFundsException;
import com.example.banking.exception.ResourceNotFoundException;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.TransactionRepository;
import com.example.banking.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AccountService {
    private static final SecureRandom RANDOM = new SecureRandom();

    private final AccountRepository accounts;
    private final UserRepository users;
    private final TransactionRepository transactions;
    private final NotificationService notifications;

    @Transactional
    public AccountResponse createAccount(String username) {
        User owner = users.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Account a = new Account();
        a.setAccountNumber(generateAccountNumber());
        a.setBalance(BigDecimal.ZERO);
        a.setOwner(owner);
        accounts.save(a);
        return AccountResponse.from(a);
    }

    @Transactional(readOnly = true)
    public List<AccountResponse> myAccounts(String username) {
        return accounts.findByOwnerUsername(username).stream().map(AccountResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public List<AccountResponse> allAccounts() {
        return accounts.findAll().stream().map(AccountResponse::from).toList();
    }

    @Transactional
    public AccountResponse deposit(String accountNumber, BigDecimal amount, String username) {
        Account a = getOwnedAccount(accountNumber, username);
        a.setBalance(a.getBalance().add(amount));
        record(a, TransactionType.DEPOSIT, amount, "Deposit");
        notifications.notifyIfLarge(username, "deposit", amount);
        return AccountResponse.from(a);
    }

    @Transactional
    public AccountResponse withdraw(String accountNumber, BigDecimal amount, String username) {
        Account a = getOwnedAccount(accountNumber, username);
        ensureSufficient(a, amount);
        a.setBalance(a.getBalance().subtract(amount));
        record(a, TransactionType.WITHDRAW, amount, "Withdrawal");
        notifications.notifyIfLarge(username, "withdrawal", amount);
        return AccountResponse.from(a);
    }

    /**
     * Both balance updates and both ledger entries happen in ONE database transaction:
     * if anything fails, everything rolls back and no money is lost or created.
     */
    @Transactional
    public AccountResponse transfer(TransferRequest req, String username) {
        if (req.fromAccount().equals(req.toAccount())) {
            throw new IllegalArgumentException("Cannot transfer to the same account");
        }
        Account from = getOwnedAccount(req.fromAccount(), username);
        Account to = accounts.findByAccountNumber(req.toAccount())
                .orElseThrow(() -> new ResourceNotFoundException("Destination account not found"));
        ensureSufficient(from, req.amount());

        from.setBalance(from.getBalance().subtract(req.amount()));
        to.setBalance(to.getBalance().add(req.amount()));
        record(from, TransactionType.TRANSFER_OUT, req.amount(), "Transfer to " + to.getAccountNumber());
        record(to, TransactionType.TRANSFER_IN, req.amount(), "Transfer from " + from.getAccountNumber());
        notifications.notifyIfLarge(username, "transfer", req.amount());
        return AccountResponse.from(from);
    }

    @Transactional(readOnly = true)
    public Page<TransactionResponse> history(String accountNumber, TransactionType type,
                                             Pageable pageable, String username) {
        Account a = getOwnedAccount(accountNumber, username);
        return transactions.search(a.getId(), type, pageable).map(TransactionResponse::from);
    }

    @Transactional(readOnly = true)
    public MonthlyReport monthlyReport(String accountNumber, int year, int month, String username) {
        Account a = getOwnedAccount(accountNumber, username);
        YearMonth ym = YearMonth.of(year, month);
        LocalDateTime from = ym.atDay(1).atStartOfDay();
        LocalDateTime to = ym.plusMonths(1).atDay(1).atStartOfDay();
        BigDecimal in = transactions.sumByTypes(a.getId(),
                List.of(TransactionType.DEPOSIT, TransactionType.TRANSFER_IN), from, to);
        BigDecimal out = transactions.sumByTypes(a.getId(),
                List.of(TransactionType.WITHDRAW, TransactionType.TRANSFER_OUT), from, to);
        return new MonthlyReport(accountNumber, year, month, in, out, in.subtract(out));
    }

    // ---- helpers ----

    private Account getOwnedAccount(String accountNumber, String username) {
        Account a = accounts.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + accountNumber));
        if (!a.getOwner().getUsername().equals(username)) {
            throw new AccessDeniedException("Not your account");
        }
        return a;
    }

    private void ensureSufficient(Account a, BigDecimal amount) {
        if (a.getBalance().compareTo(amount) < 0) {
            throw new InsufficientFundsException("Insufficient funds. Balance: " + a.getBalance());
        }
    }

    private void record(Account a, TransactionType type, BigDecimal amount, String description) {
        Transaction t = new Transaction();
        t.setAccount(a);
        t.setType(type);
        t.setAmount(amount);
        t.setBalanceAfter(a.getBalance());
        t.setDescription(description);
        transactions.save(t);
    }

    private String generateAccountNumber() {
        String number;
        do {
            number = "AC" + String.format("%010d", Math.abs(RANDOM.nextLong() % 10_000_000_000L));
        } while (accounts.findByAccountNumber(number).isPresent());
        return number;
    }
}
