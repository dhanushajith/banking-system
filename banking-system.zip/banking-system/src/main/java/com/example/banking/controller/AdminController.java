package com.example.banking.controller;

import com.example.banking.dto.Dtos.AccountResponse;
import com.example.banking.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {
    private final AccountService service;

    @GetMapping("/accounts")
    public List<AccountResponse> allAccounts() { return service.allAccounts(); }
}
