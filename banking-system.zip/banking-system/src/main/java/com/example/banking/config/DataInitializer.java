package com.example.banking.config;

import com.example.banking.entity.Role;
import com.example.banking.entity.User;
import com.example.banking.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

/** Seeds a demo admin user (username: admin / password: admin123). Remove for production. */
@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner seedAdmin(UserRepository users, PasswordEncoder encoder) {
        return args -> {
            if (!users.existsByUsername("admin")) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(encoder.encode("admin123"));
                admin.setEmail("admin@bank.local");
                admin.setRole(Role.ADMIN);
                users.save(admin);
            }
        };
    }
}
