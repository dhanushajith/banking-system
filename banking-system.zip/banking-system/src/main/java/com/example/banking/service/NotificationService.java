package com.example.banking.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Alerts the user about large transactions. Currently logs the message;
 * swap the log line for JavaMailSender (spring-boot-starter-mail) to send real emails.
 */
@Slf4j
@Service
public class NotificationService {
    private final BigDecimal threshold;

    public NotificationService(@Value("${app.notification.large-amount}") BigDecimal threshold) {
        this.threshold = threshold;
    }

    public void notifyIfLarge(String username, String action, BigDecimal amount) {
        if (amount.compareTo(threshold) >= 0) {
            log.warn("[ALERT] Large {} of {} by user '{}'", action, amount, username);
        }
    }
}
