package com.example.banking.repository;

import com.example.banking.entity.Transaction;
import com.example.banking.entity.TransactionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collection;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    @Query("select t from Transaction t where t.account.id = :accountId " +
           "and (:type is null or t.type = :type)")
    Page<Transaction> search(@Param("accountId") Long accountId,
                             @Param("type") TransactionType type,
                             Pageable pageable);

    @Query("select coalesce(sum(t.amount), 0) from Transaction t where t.account.id = :accountId " +
           "and t.type in :types and t.createdAt >= :from and t.createdAt < :to")
    BigDecimal sumByTypes(@Param("accountId") Long accountId,
                          @Param("types") Collection<TransactionType> types,
                          @Param("from") LocalDateTime from,
                          @Param("to") LocalDateTime to);
}
