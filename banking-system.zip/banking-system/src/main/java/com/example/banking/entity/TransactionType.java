package com.example.banking.entity;

public enum TransactionType { DEPOSIT, WITHDRAW, TRANSFER_IN, TRANSFER_OUT }
