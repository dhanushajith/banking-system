package com.example.banking.dto;

import com.example.banking.entity.Account;
import com.example.banking.entity.Transaction;
import com.example.banking.entity.TransactionType;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public final class Dtos {
    private Dtos() {}

    public record RegisterRequest(
            @NotBlank @Size(min = 3, max = 30) String username,
            @NotBlank @Size(min = 6, max = 100) String password,
            @NotBlank @Email String email) {}

    public record LoginRequest(@NotBlank String username, @NotBlank String password) {}

    public record AuthResponse(String token) {}

    public record AmountRequest(@NotNull @DecimalMin("0.01") BigDecimal amount) {}

    public record TransferRequest(
            @NotBlank String fromAccount,
            @NotBlank String toAccount,
            @NotNull @DecimalMin("0.01") BigDecimal amount) {}

    public record AccountResponse(String accountNumber, BigDecimal balance) {
        public static AccountResponse from(Account a) {
            return new AccountResponse(a.getAccountNumber(), a.getBalance());
        }
    }

    public record TransactionResponse(TransactionType type, BigDecimal amount, BigDecimal balanceAfter,
                                      String description, LocalDateTime createdAt) {
        public static TransactionResponse from(Transaction t) {
            return new TransactionResponse(t.getType(), t.getAmount(), t.getBalanceAfter(),
                    t.getDescription(), t.getCreatedAt());
        }
    }

    public record MonthlyReport(String accountNumber, int year, int month,
                                BigDecimal totalIn, BigDecimal totalOut, BigDecimal net) {}
}
