package com.example.banking.controller;

import com.example.banking.dto.Dtos.*;
import com.example.banking.entity.TransactionType;
import com.example.banking.service.AccountService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
public class AccountController {
    private final AccountService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AccountResponse create(Principal p) { return service.createAccount(p.getName()); }

    @GetMapping
    public List<AccountResponse> mine(Principal p) { return service.myAccounts(p.getName()); }

    @PostMapping("/{accountNumber}/deposit")
    public AccountResponse deposit(@PathVariable String accountNumber,
                                   @Valid @RequestBody AmountRequest req, Principal p) {
        return service.deposit(accountNumber, req.amount(), p.getName());
    }

    @PostMapping("/{accountNumber}/withdraw")
    public AccountResponse withdraw(@PathVariable String accountNumber,
                                    @Valid @RequestBody AmountRequest req, Principal p) {
        return service.withdraw(accountNumber, req.amount(), p.getName());
    }

    @PostMapping("/transfer")
    public AccountResponse transfer(@Valid @RequestBody TransferRequest req, Principal p) {
        return service.transfer(req, p.getName());
    }

    /** Paginated + filterable: /transactions?type=DEPOSIT&page=0&size=10 */
    @GetMapping("/{accountNumber}/transactions")
    public Page<TransactionResponse> history(@PathVariable String accountNumber,
                                             @RequestParam(required = false) TransactionType type,
                                             @PageableDefault(size = 10, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable,
                                             Principal p) {
        return service.history(accountNumber, type, pageable, p.getName());
    }

    @GetMapping("/{accountNumber}/report")
    public MonthlyReport report(@PathVariable String accountNumber,
                                @RequestParam int year, @RequestParam int month, Principal p) {
        return service.monthlyReport(accountNumber, year, month, p.getName());
    }
}
